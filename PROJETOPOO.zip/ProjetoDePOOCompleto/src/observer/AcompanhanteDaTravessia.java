package observer;

public interface AcompanhanteDaTravessia {
    void acompanhar(String mensagem);
}