package observer;


public class PaiDeMaria implements AcompanhanteDaTravessia {
	 @Override
	    public void acompanhar(String mensagem) {
	        System.out.println("Pai de Maria: " + mensagem +"\n");

	 }
}
