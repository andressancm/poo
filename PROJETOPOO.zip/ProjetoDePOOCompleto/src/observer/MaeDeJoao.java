package observer;


// Implementação de um observador específico: sistema de monitoramento
public class MaeDeJoao implements AcompanhanteDaTravessia {
    @Override
    public void acompanhar(String mensagem) {
        System.out.println("Mãe de João: " + mensagem +"\n");
    }
}