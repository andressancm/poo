package observer;


public class Regina implements AcompanhanteDaTravessia {

	@Override
	public void acompanhar(String mensagem) {
        System.out.println("Regina estava atoa e parou na travessia: "+ mensagem);

	}

}
