package decorator;

// Implementação concreta: barco como recurso
public class PranchaRecurso extends Recurso {
    public PranchaRecurso() {
        this.descricao = "Prancha";
    }

    @Override
    public double getCusto() {
        return 30.0; // Custo base
    }
}
