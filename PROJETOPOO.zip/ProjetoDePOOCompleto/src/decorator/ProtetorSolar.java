package decorator;

// Equipamento específico: Protetor Solar
public class ProtetorSolar extends Equipamento {
    public ProtetorSolar(Recurso recurso) {
        super(recurso);
    }

    @Override
    public String getDescricao() {
        return super.getDescricao() + ", Protetor solar";
    }

    @Override
    public double getCusto() {
        return super.getCusto() + 5.0; // Custo do protetor solar
    }
}
