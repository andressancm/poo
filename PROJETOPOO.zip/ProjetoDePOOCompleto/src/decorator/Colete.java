package decorator;

// Equipamento específico: colete
public class Colete extends Equipamento {
    public Colete(Recurso recurso) {
        super(recurso);
        this.descricao = "Colete";
    }

    @Override
    public double getCusto() {
        return recurso.getCusto() + 15.0;
    }
}
