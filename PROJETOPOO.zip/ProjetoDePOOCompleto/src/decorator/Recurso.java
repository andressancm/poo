package decorator;

// Classe base para recursos da travessia
public abstract class Recurso {
    protected String descricao = "Recurso desconhecido";

    public String getDescricao() {
        return descricao;
    }

    public abstract double getCusto();
}

