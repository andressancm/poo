package decorator;

// Decorador específico: adiciona um capacete à travessia
public class Capacete extends Equipamento {
    public Capacete(Recurso recurso) {
        super(recurso);
        this.descricao = "Capacete";
    }

    @Override
    public double getCusto() {
        return recurso.getCusto() + 10.0; // Adiciona o custo do capacete
    }
}

