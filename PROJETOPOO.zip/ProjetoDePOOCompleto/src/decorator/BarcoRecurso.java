package decorator;

// Implementação concreta: barco como recurso
public class BarcoRecurso extends Recurso {
    public BarcoRecurso() {
        this.descricao = "Barco";
    }

    @Override
    public double getCusto() {
        return 50.0; // Custo base
    }
}
