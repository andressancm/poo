package decorator;

// Equipamento específico: Óculos de Natação
public class OculosNatacao extends Equipamento {
    public OculosNatacao(Recurso recurso) {
        super(recurso);
        this.descricao = "Óculos de Natação";
    }

    @Override
    public double getCusto() {
        return recurso.getCusto() + 10.0; // Custo adicional
    }
}
