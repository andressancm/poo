package decorator;

// Decorador: equipamento para recursos
public abstract class Equipamento extends Recurso {
    protected Recurso recurso;

    public Equipamento(Recurso recurso) {
        this.recurso = recurso;
    }

    @Override
    public String getDescricao() {
        return recurso.getDescricao() + ", " + descricao;
    }
@Override
public double getCusto() {
    return recurso.getCusto(); // Adiciona ao custo
}
}


