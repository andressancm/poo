package Projetopadroes;

import observer.*;
import strategy.*;
import decorator.*;

public class Teste {
    public static void main(String[] args) {
        // **João:**
        Viajante joao = new Viajante("João");
        joao.setModoTravessia(new Prancha()); // João vai de prancha
        MaeDeJoao maeDeJoao = new MaeDeJoao(); // Mãe de João observa
        joao.adicionarAcompanhante(maeDeJoao);
        Regina regina = new Regina(); // Regina observa
        joao.adicionarAcompanhante(regina);
        joao.removerAcompanhante(regina);

        // **Maria:**
        Viajante maria = new Viajante("Maria");
        maria.setModoTravessia(new UsarBarco()); // Maria vai de barco
        PaiDeMaria paiDeMaria = new PaiDeMaria(); // Pai de Maria observa
        maria.adicionarAcompanhante(paiDeMaria);

        // **João começa a travessia**
        System.out.println("\n--------------- Travessia de João ---------------------");
        joao.atravessar();
        
        System.out.println("\n------------- Equipamentos e Custos -------------------");
        
        Recurso pranchaJoao = new PranchaRecurso(); // Prancha para João
        System.out.printf("Equipamento João: %s | Custo: R$ %.2f%n",pranchaJoao.getDescricao(), pranchaJoao.getCusto());
        pranchaJoao = new Capacete(pranchaJoao); // Equipando João com capacete
        pranchaJoao = new ProtetorSolar(pranchaJoao);
        System.out.printf("Equipamento adicional João: Capacete, Protetor solar | Custo: R$ %.2f%n", 15.0);
        System.out.printf("Custo total para João: R$ %.2f%n", pranchaJoao.getCusto());

        // **Maria começa a travessia**
        System.out.println("\n--------------- Travessia de Maria  ---------------------");
        maria.atravessar();
        
        System.out.println("\n------------- Equipamentos e Custos -------------------");
        
        Recurso barcoMaria = new BarcoRecurso(); // Barco para Maria
        System.out.printf("\nEquipamento Maria: %s | Custo: R$ %.2f%n", barcoMaria.getDescricao(), barcoMaria.getCusto());
        barcoMaria = new Colete(barcoMaria); // Equipando Maria com colete
        barcoMaria = new ProtetorSolar(barcoMaria);
        System.out.printf("Equipamento adicional Maria: Colete, Protetor solar | Custo: R$ %.2f%n", 20.0);
        System.out.printf("Custo total para Maria: R$ %.2f%n", barcoMaria.getCusto());
    }

       
}

