package Projetopadroes;

import java.util.ArrayList;
import java.util.List;

import decorator.Recurso;
import observer.*;
import strategy.ModoTravessia;

public class Viajante {
    private String nome;
    private ModoTravessia modoTravessia;
    private List<AcompanhanteDaTravessia> acompanhantes = new ArrayList<>();
    private Recurso recursoAdicional;

    public Viajante(String nome) {
        this.nome = nome;
    }

    public void setModoTravessia(ModoTravessia modoTravessia) {
        this.modoTravessia = modoTravessia;
    }

    public void setRecursoAdicional(Recurso recurso) {
        this.recursoAdicional = recurso;
    }

    public void adicionarAcompanhante(AcompanhanteDaTravessia acompanhante) {
    	acompanhantes.add(acompanhante);
    }

    public void removerAcompanhante(AcompanhanteDaTravessia acompanhante) {
    	acompanhantes.remove(acompanhante);
    }

    public void atravessar() {
        notificarAcompanhante(nome + " está começando a travessia.");
        if (modoTravessia != null) {
            modoTravessia.atravessar();
        } else {
            System.out.println("Modo de travessia não definido!");
        }
        if (recursoAdicional != null) {
            System.out.println("Recurso utilizado: " + recursoAdicional.getDescricao() + " | Custo: R$ " + recursoAdicional.getCusto());
        }
        notificarAcompanhante(nome + " terminou a travessia.");
    }

    private void notificarAcompanhante(String mensagem) {
        for (AcompanhanteDaTravessia observador : acompanhantes) {
            observador.acompanhar(mensagem);
        }
    }
}

	
