package strategy;

// Implementação do modo "Nadar"
public class Nadar implements ModoTravessia {
    @Override
    public void atravessar() {
        System.out.println("Atravessando o rio nadando!\n");
    }
}
