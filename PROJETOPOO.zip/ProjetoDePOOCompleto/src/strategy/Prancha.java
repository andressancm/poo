package strategy;

// Implementação do modo "prancha"
public class Prancha implements ModoTravessia {
    @Override
    public void atravessar() {
        System.out.println("Atravessando o rio dando grau de prancha!\n");
    }
}
