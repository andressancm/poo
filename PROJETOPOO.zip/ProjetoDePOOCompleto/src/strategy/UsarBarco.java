package strategy;

// Implementação do modo "Usar Barco"
public class UsarBarco implements ModoTravessia {
    @Override
    public void atravessar() {
        System.out.println("Atravessando o rio de barco!\n");
    }
}
