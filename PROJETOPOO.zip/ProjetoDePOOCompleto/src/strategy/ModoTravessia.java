package strategy;

// Interface do padrão Strategy: modos de travessia
public interface ModoTravessia {
    void atravessar();
}

